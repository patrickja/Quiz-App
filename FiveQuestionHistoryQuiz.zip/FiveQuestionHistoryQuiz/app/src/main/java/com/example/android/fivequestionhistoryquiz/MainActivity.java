package com.example.android.fivequestionhistoryquiz;

import android.support.v7.app.AppCompatActivity;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {


    int totalScore = 0;
   private RadioGroup radioGroup1;
   private RadioGroup radioGroup2;
   private RadioGroup radioGroup3;
   private RadioGroup radioGroup4;
   private RadioGroup radioGroup5;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup1 = (RadioGroup) findViewById(R.id.radioGroup1);
        radioGroup1.clearCheck();

        radioGroup2 = (RadioGroup) findViewById(R.id.radioGroup2);
        radioGroup2.clearCheck();

        radioGroup3 = (RadioGroup) findViewById(R.id.radioGroup3);
        radioGroup3.clearCheck();

        radioGroup4 = (RadioGroup) findViewById(R.id.radioGroup4);
        radioGroup4.clearCheck();

        radioGroup5 = (RadioGroup) findViewById(R.id.radioGroup5);
        radioGroup5.clearCheck();

        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb1 = (RadioButton) group.findViewById(checkedId);
                if (null != rb1 && checkedId > -1) {
                    //Toast.makeText(MainActivity.this, rb1.getText(), Toast.LENGTH_SHORT).show();
                }
            }

        });

        radioGroup2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb2 = (RadioButton) group.findViewById(checkedId);
                if (null != rb2 && checkedId > -1) {
                    //Toast.makeText(MainActivity.this, rb2.getText(), Toast.LENGTH_SHORT).show();
                }
            }

        });

        radioGroup3.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb3 = (RadioButton) group.findViewById(checkedId);
                if (null != rb3 && checkedId > -1) {
                    //Toast.makeText(MainActivity.this, rb3.getText(), Toast.LENGTH_SHORT).show();
                }
            }

        });

        radioGroup4.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb4 = (RadioButton) group.findViewById(checkedId);
                if (null != rb4 && checkedId > -1) {
                    //Toast.makeText(MainActivity.this, rb4.getText(), Toast.LENGTH_SHORT).show();
                }
            }

        });

        radioGroup5.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb5 = (RadioButton) group.findViewById(checkedId);
                if (null != rb5 && checkedId > -1) {
                    //Toast.makeText(MainActivity.this, rb5.getText(), Toast.LENGTH_SHORT).show();
                }
            }

        });
    }


    public void clearAnswers5 (View v) {
        /*Clears All Selected radio Buttons to Default */
        radioGroup1.clearCheck();
        radioGroup2.clearCheck();
        radioGroup3.clearCheck();
        radioGroup4.clearCheck();
        radioGroup5.clearCheck();
    }

    public void submitAnswers5(View v) {
        RadioButton rb1 = (RadioButton) radioGroup1.findViewById(radioGroup1.getCheckedRadioButtonId());
        if (rb1 != null) {
            if (rb1 == findViewById(R.id.qOneAnswerA)) {

                Toast.makeText(MainActivity.this, "Question #1 Correct, +1 Point!", Toast.LENGTH_SHORT).show();
                totalScore = totalScore + 1;
            } else {
                Toast.makeText(MainActivity.this, "Question #1 is incorrect, Try again!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Please make a Selection for Question #1", Toast.LENGTH_SHORT).show();
        }

        RadioButton rb2 = (RadioButton) radioGroup2.findViewById(radioGroup2.getCheckedRadioButtonId());
        if(rb2 != null) {
            if(rb2 == findViewById(R.id.qTwoAnswerC)) {

                Toast.makeText(MainActivity.this, "Question #2 Correct, +1 Point!", Toast.LENGTH_SHORT).show();
                totalScore = totalScore + 1;
            }
            else {
                Toast.makeText(MainActivity.this, "Question #2 is incorrect, Try again!", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(MainActivity.this, "Please make a Selection for Question #2", Toast.LENGTH_SHORT).show();
        }

        RadioButton rb3 = (RadioButton) radioGroup3.findViewById(radioGroup3.getCheckedRadioButtonId());
        if(rb3 != null) {
            if(rb3 == findViewById(R.id.qThreeAnswerD)) {

                Toast.makeText(MainActivity.this, "Question #3 Correct, +1 Point!", Toast.LENGTH_SHORT).show();
                totalScore = totalScore + 1;
            }
            else {
                Toast.makeText(MainActivity.this, "Question #3 is incorrect, Try again!", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(MainActivity.this, "Please make a Selection for Question #3", Toast.LENGTH_SHORT).show();
        }

        RadioButton rb4 = (RadioButton) radioGroup4.findViewById(radioGroup4.getCheckedRadioButtonId());
        if(rb4 != null) {
            if(rb4 == findViewById(R.id.qFourAnswerA)) {

                Toast.makeText(MainActivity.this, "Question #4 Correct, +1 Point!", Toast.LENGTH_SHORT).show();
                totalScore = totalScore + 1;
            }
            else {
                Toast.makeText(MainActivity.this, "Question #4 is incorrect, Try again!", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(MainActivity.this, "Please make a Selection for Question #4", Toast.LENGTH_SHORT).show();
        }

        RadioButton rb5 = (RadioButton) radioGroup5.findViewById(radioGroup5.getCheckedRadioButtonId());
        if (rb5 != null) {
            if (rb5 == findViewById(R.id.qFiveAnswerD)) {

                Toast.makeText(MainActivity.this, "Question #5 Correct, +1 Point!", Toast.LENGTH_SHORT).show();
                totalScore = totalScore + 1;
            } else {
                Toast.makeText(MainActivity.this, "Question #5 is incorrect, Try again!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Please make a Selection for Question #5", Toast.LENGTH_SHORT).show();
        }
        String scoreMessage = "Your Final Score is: " + totalScore;
        scoreMessage = scoreMessage + " points!";

        Toast.makeText(MainActivity.this, scoreMessage, Toast.LENGTH_LONG).show();
    }

}



